package io.github.mosiki.util;

public interface Constants {

    String SALES_LIST = "phone:sales:list";

    String BUY_DYNAMIC = "phone:buy:dynamic";

    String separator = "#";

}
