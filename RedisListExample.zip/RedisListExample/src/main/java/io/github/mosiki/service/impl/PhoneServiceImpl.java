package io.github.mosiki.service.impl;

import io.github.mosiki.entity.Phone;
import io.github.mosiki.service.PhoneService;
import io.github.mosiki.util.Constants;
import io.github.mosiki.util.RedisUtil;
import io.github.mosiki.util.StringUtil;
import io.github.mosiki.vo.DynamicVO;
import io.github.mosiki.vo.PhoneVO;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Tuple;

import javax.annotation.PostConstruct;
import java.util.*;

@Service
public class PhoneServiceImpl implements PhoneService {

    List<Phone> phones = Arrays.asList(new Phone(1, "苹果"),
            new Phone(2, "小米"),
            new Phone(3, "华为"),
            new Phone(4, "一加"),
            new Phone(5, "vivo"));

    Jedis jedis = null;
    @PostConstruct
    public void initRedisClient () {
        // 注：保持代码简介，未使用 JedisPool 生产环境应使用连接池
        jedis = RedisUtil.getJedis();
    }

    @Override
    public void buyPhone(int phoneId) {
    	/**
    	 * 如果成员已经存在于排序集中，则自增1，并相应地更新元素在排序集中的位置。
    	 * 如果成员在排序的集合中不存在，则自增1（也就是说，前面的排名实际上为零）。
    	 * 如果key不存在，则以指定成员作为唯一成员的新排序集被装箱。
    	 * 如果存在key但不保存排序的设置值，则返回错误。
    	 */
    	// 购买成功则对排行榜中该手机的销量进行加1
        jedis.zincrby(Constants.SALES_LIST, 1, String.valueOf(phoneId));

        // 添加购买动态
        long currentTimeMillis = System.currentTimeMillis();
        String msg = currentTimeMillis + Constants.separator + phones.get(phoneId - 1).getName();
        jedis.lpush(Constants.BUY_DYNAMIC, msg);
    }

    @Override
    public List<PhoneVO> getPhbList() {
        // 按照销量多少排行，取出前五名
        Set<Tuple> tuples = jedis.zrevrangeWithScores(Constants.SALES_LIST, 0, 4);
        List<PhoneVO> list = new ArrayList<>();
        for (Tuple tuple : tuples) {
            PhoneVO vo = new PhoneVO();
            // 取出对应 phoneId 的手机名称
            int phoneId = Integer.parseInt(tuple.getElement());
            vo.setName(phones.get(phoneId - 1).getName());
            vo.setSales((int) tuple.getScore());
            list.add(vo);
        }
        return list;
    }

    @Override
    public List<DynamicVO> getBuyDynamic() {

        List<DynamicVO> dynamicList = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
        	/**
        	 * 返回存储在指定key的列表的指定元素。0是第一个元素，1是第二个元素，依此类推。支持负索引，例如-1是最后一个元素，-2是倒数第二个元素，依此类推。
        	 * 如果存储在key上的值不是列表类型，则返回错误。如果索引超出范围，则返回“nil”答复。
        	 */
            String result = jedis.lindex(Constants.BUY_DYNAMIC, i);
            if (StringUtils.isEmpty(result)) {
                break;
            }
            String[] arr = result.split(Constants.separator);
            long time = Long.valueOf(arr[0]);
            String phone = arr[1];
            DynamicVO vo = new DynamicVO();
            vo.setPhone(phone);
            vo.setTime(StringUtil.showTime(new Date(time)));
            dynamicList.add(vo);
        }

        // 只保留队列中20个销售动态
        jedis.ltrim(Constants.BUY_DYNAMIC, 0, 19);
        return dynamicList;
    }

    @Override
    public int phoneRank(int phoneId) {
        /**
         *  返回排序集合中的排名（或索引）或成员，分数从高到低排序
         *  当给定成员在排序集中不存在时，返回特殊值"0"。
         *  时间复杂性：O(log(N))
         */
        Long zrank = jedis.zrevrank(Constants.SALES_LIST, String.valueOf(phoneId));
        return zrank == null ? -1 : zrank.intValue();
    }

    @Override
    public void clear() {
        jedis.del(Constants.SALES_LIST);
        jedis.del(Constants.BUY_DYNAMIC);
    }

    @Override
    public void initCache() {
        Map<String, Double> map = new HashMap<>();
        map.put("1", 4.0);
        map.put("2", 2.0);
        map.put("3", 3.0);
        jedis.zadd(Constants.SALES_LIST, map);
    }
}
